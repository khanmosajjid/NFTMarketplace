import React, { useState, useEffect } from "react";
import CollectionsNfts from "../components/CollectionsNfts";
// import ColumnZeroTwo from "../components/ColumnZeroTwo";
import Footer from "../components/footer";
import { createGlobalStyle } from "styled-components";
import {
  GetCollectionsByAddress,
  GetIndividualAuthorDetail,
  GetMetaOfCollection,
  getProfile
} from "../../apiServices";
import Loader from "../components/loader";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { useParams } from "react-router-dom";
import { NotificationManager } from "react-notifications";
import Avatar from "./../../assets/images/avatar5.jpg";
import { useCookies } from "react-cookie";
import { convertToEth } from "../../helpers/numberFormatter";

const GlobalStyles = createGlobalStyle`
header#myHeader.navbar.white a {

    color: #fff;

  }

  header#myHeader.navbar.white.sticky a{

    color: #111;

  }

  header#myHeader.navbar.white .logo .d-none{

    display: block !important;

  }

  header#myHeader.navbar.white .logo .d-block{

    display: none !important;

  }

  header#myHeader.navbar.white.sticky .logo .d-none{

    display: none !important;

  }

  header#myHeader.navbar.white.sticky .logo .d-block{

    display: block !important;

  }

  @media only screen and (max-width: 1199px) {

    .navbar{

      background: #403f83;

    }

    .navbar .menu-line, .navbar .menu-line1, .navbar .menu-line2{

      background: #111;

    }

    .item-dropdown .dropdown a{

      color: #111 !important;

    }

  }
`;

const Collection = function (props) {
  const [openMenu, setOpenMenu] = useState(true);
  const [openMenu1, setOpenMenu1] = useState(false);
  const [loading, setLoading] = useState(false);
  const [authorDetails, setAuthorDetails] = useState(false);
  const [collectionDetails, setCollectionDetails] = useState([]);
  const [profile, setProfile] = useState();
  const [currentUser, setCurrentUser] = useState();
  const [cookies] = useCookies(["selected_account", "Authorization"]);
  const [metaData, setMetaData]=useState({})
  useEffect(() => {
    if (cookies.selected_account) setCurrentUser(cookies.selected_account);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cookies.selected_account]);

  useEffect(() => {
    const fetch = async () => {
      if (currentUser) {
        let _profile = await getProfile();
        setProfile(_profile);
      }
    };
    fetch();
  }, [currentUser]);

  let { address } = useParams();
  let addr = address;

  useEffect(() => {
    async function fetch() {
      if (addr) {
        setLoading(true);
        let data = await GetCollectionsByAddress({ sContractAddress: addr });

        setCollectionDetails(data);

        setLoading(false);
      }
    }
    fetch();
  }, [addr]);

  useEffect(() => {
    async function fetch() {
      if (collectionDetails) {
        setLoading(true);
        let data = await GetIndividualAuthorDetail({
          userId: collectionDetails.oCreatedBy,
          currUserId: profile ? profile._id : "",
        });
        
        let metadata = await GetMetaOfCollection({ collectionId: collectionDetails.sContractAddress });
      //  metaData['floorPrice']=convertToEth(metadata.floorPrice)
        setMetaData(metadata)
        setAuthorDetails(data);

        setLoading(false);
      }
    }
    fetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionDetails, profile]);

  const handleBtnClick = () => {
    setOpenMenu(true);
    setOpenMenu1(false);
    document.getElementById("Mainbtn").classList.add("active");
    document.getElementById("Mainbtn1").classList.remove("active");
  };
  const handleBtnClick1 = () => {
    setOpenMenu1(true);
    setOpenMenu(false);
    document.getElementById("Mainbtn1").classList.add("active");
    document.getElementById("Mainbtn").classList.remove("active");
  };

  return loading ? (
    <Loader />
  ) : (
    <div className="collection_cd">
      <GlobalStyles />
      <section
        id="profile_banner"
        className="jumbotron no-bg background-img"
        style={{
          backgroundImage: `url(${collectionDetails.collectionImage})`,
        }}
      >
        <div className="container">
          <div className="mainbreadcumb1"></div>
        </div>
      </section>

      <section className="container d_coll no-top no-bottom">
        <div className="row">
          <div className="col-md-12">
            <div className="coll_profile">
              <div className="coll_profile_avatar">
                <div className="coll_profile_img">
                  <a href={"/author/" + authorDetails._id} >
                    <img
                      src={
                        authorDetails.sProfilePicUrl
                          ? authorDetails.sProfilePicUrl
                          : Avatar
                      }
                      alt=""
                    />
                  </a>
                  <i className="fa fa-check"></i>
                </div>

                <div className="profile_name">
                  <h4 className="font_36 text-dark NunitoBold mb-0 mt-3">
                    {collectionDetails ? collectionDetails.sName : ""}
                  </h4>

                  <CopyToClipboard
                    text={
                      collectionDetails
                        ? collectionDetails.sContractAddress
                        : ""
                    }
                    onCopy={() => {
                      NotificationManager.success("Copied!!");
                    }}
                  >
                    <div id="wallet" className="profile_wallet font_18 text-dark NunitoLight">
                      {collectionDetails && collectionDetails.sContractAddress
                        ?
                        collectionDetails.sContractAddress.slice(0, 5) +
                        "......" +
                        collectionDetails.sContractAddress.slice(37, 42) : ""
                      }
                      {/*                        
                        {collectionDetails
                          ? collectionDetails.sContractAddress
                          : ""}*/}
                    </div>
                    {/* <button id="btn_copy" title="Copy Text">
                        Copy
                      </button> */}
                  </CopyToClipboard>

                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="collection-desc">
        <h3>{collectionDetails.sDescription}</h3>
      </div>
      <section className="collection-detail-card">
        <div className="collection-card">
          <h1>Floor Price</h1>
          <p>${convertToEth(metaData.floorPrice)}</p>
        </div>
        <div className="collection-card">
          <h1>Trade Volume</h1>
          <p>3000</p>
        </div>
        <div className="collection-card">
          <h1>Latest Price</h1>
          <p>3000</p>
        </div>
        <div className="collection-card">
          <h1>Total Items</h1>
          <p>{metaData.items}</p>
        </div>
      </section>

      <section className="container no-top">
        <div className="row mt-4 mb-5">
          <div className="col-lg-12">
            <div className="items_filter">
              <ul className="de_nav">
                <li id="Mainbtn" className="active">
                  <span onClick={handleBtnClick}>On Sale</span>
                </li>
                <li id="Mainbtn1" className="">
                  <span onClick={handleBtnClick1}>Owned</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
        {openMenu && (
          <div id="zero1" className="onStep fadeIn" >
            <CollectionsNfts
              owned={false}
              collection={
                collectionDetails ? collectionDetails.sContractAddress : ""}

            // collectionDetails && collectionDetails.sContractAddress ? <video className="img-fluid nftimg" controls>
            //   <source  src={`https://${collectionDetails.nNftImage}`} type="video/mp4" />
            // </video>
            //   : ""}
            />


          </div>
        )}
        {openMenu1 && (
          <div id="zero2" className="onStep fadeIn">
            <CollectionsNfts
              owned={true}
              collection={
                collectionDetails ? collectionDetails.sContractAddress : ""
              }
            />
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
};



export default Collection;
