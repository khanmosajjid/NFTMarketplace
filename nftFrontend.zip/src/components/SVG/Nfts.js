import React from 'react'

const Nfts = () => {
  return (
    <svg version="1.2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 36" width="50" height="36"><defs><linearGradient id="P" gradientUnits="userSpaceOnUse"/><linearGradient id="g11" x1="9.5" y1="6" x2="45" y2="36" href="#P"><stop stop-color="#fff"/><stop offset=".4" stop-color="#fff"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><style></style><path fill-rule="evenodd" className="a2" d="m50 25.5c0 5.5-4.5 10-10 10h-28.8c-6.2 0-11.2-5-11.2-11.3 0-4.9 3.1-9 7.5-10.6q0-0.3 0-0.6c0-6.9 5.6-12.5 12.5-12.5 4.6 0 8.7 2.5 10.8 6.3 1.2-0.8 2.7-1.3 4.2-1.3 4.1 0 7.5 3.4 7.5 7.5q0 1.4-0.5 2.7c4.6 0.9 8 5 8 9.8zm-18.4-7.1l-8.2-8.3c-0.5-0.5-1.3-0.5-1.8 0l-8.2 8.3c-0.8 0.8-0.3 2.1 0.9 2.1h5.1v8.8c0 0.6 0.5 1.2 1.2 1.2h3.8c0.7 0 1.2-0.6 1.2-1.3v-8.7h5.1c1.1 0 1.7-1.3 0.9-2.1z"/></svg>
  )
}

export default Nfts
