export const slowRefresh = () => {
  setTimeout(() => window.location.reload(), 1000);
};
