// MUMBAI
REACT_APP_CHAIN_ID = 80001;

REACT_APP_BASE_URL = "";

REACT_APP_RPC_URL = "https://rpc-mumbai.maticvigil.com/";

REACT_APP_NETWORK = "Mumbai";

REACT_APP_API_BASE_URL = "http://127.0.0.1:3000/api/v1";

FORTMATIC_API_KEY = "pk_live_7A822E92D291709C";

// BSC TESTNET
REACT_APP_CHAIN_ID = 97;

REACT_APP_BASE_URL = "";

REACT_APP_RPC_URL = "https://data-seed-prebsc-1-s2.binance.org:8545/";

REACT_APP_NETWORK = "Testnet";

/*------------------------------------------------*/

REACT_APP_API_BASE_URL = "http://127.0.0.1:3000/api/v1";

FORTMATIC_API_KEY = "pk_live_7A822E92D291709C";

URL = "http://127.0.0.1";

PORT = 3000;
