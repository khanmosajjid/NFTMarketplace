const mongodb = require('./lib/mongodb');
// const sendgrid = require('./lib/sendgrid');
const nodemailer = require('./lib/nodemailer');

module.exports = {
    mongodb,
    nodemailer
};
