global._ = require('./lib/helper');
global.log = require('./lib/log');
global.messages = require('./lib/message');
